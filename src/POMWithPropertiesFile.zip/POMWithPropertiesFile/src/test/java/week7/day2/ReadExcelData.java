/******************************************************************************
 		====================================================
	 		Workbook 	 ==> Worksheet ==> Rows ==> Cell
	 		
	 		XSSFWorkbook ==> XSSFSheet ==> Rows ==> Cell
 			
 			1.XSSFWorkbook
 			2.HSSFWorkbook
 		=====================================================
 		//Step1:- XSSFWorkbook - To get into the workbook
		XSSFWorkbook wb = new XSSFWorkbook("./data/CreateLead.xlsx");
		
		//Step2:- XSSFSheet - To get into the worksheet
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		//To get the cell count excluding Header
		int rowCount = ws.getLastRowNum();
		System.out.println(rowCount);
		
		//To get the Cell count
		short cellCount = ws.getRow(0).getLastCellNum();
		System.out.println(cellCount);
		
		//Declare 2D Array to Store the data from Excel
		String[][] data = new String[rowCount][cellCount];
		
		for (int i = 1; i <= rowCount; i++) 
		{
			for (int j = 0; j < cellCount; j++) 
			{
				String CellValue = ws.getRow(i).getCell(j).getStringCellValue();
				//System.out.print(CellValue+"		");
				data[i-1][j]=CellValue;
			}
			//System.out.println();
		}
		//Step6:- To close the workbook	
		wb.close();
		
		return data;
		
 *******************************************************************************/



package week7.day2;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData 
{
	public static void main(String[] args) throws IOException 
	{
		XSSFWorkbook wb=new XSSFWorkbook("./Data/CreateLead.xlsx");
		XSSFSheet ws = wb.getSheet("Sheet1");
		System.out.println(ws.getLastRowNum());
		System.out.println(ws.getPhysicalNumberOfRows());
		XSSFCell cell = ws.getRow(0).getCell(0);
		System.out.println(cell);
		for (int i = 0; i < args.length; i++) 
		{
			
		}
		wb.close();
		

	}

}
