/******************************************************************************************************************
	POM Rules:
	=========
		- Create BaseClass to have common variables and methods
		- Create separate Java classes for each page that you access / navigate
		- Extends BaseClass to all the pages
		- Create separate methods for each actions / verifications in respective pages
		- All the methods should have return statement and the return type is based on the control where it goes
		- Create separate java class for each testcase and extends to the BaseClass
	
	Classroom:
	===========
		Create new maven project
		Create 3 packages (base, pages, testcases)
		Create BaseClass for common variables and methods
		Create pages for each pages that you access in the application
		Create methods for each actions / verifications in respective pages
		Create CreateLead testcase and execute
		
	Steps to Make POM compatible for Parallel Execution
	===================================================
	1. Remove the static keyword from the driver
	2. Create Constructor in each page with ChromeDriver as argument
	3. Pass the driver in all the constructor calls
	
	Basic Code for Property File Access:-
 	===================================
 		1. Set the File Path for Interaction
			FileInputStream fis=new FileInputStream("./src/test/resources/English.properties");
		2. Create Object for Properties
			Properties prop=new Properties();
		3. To Load the Properties File for interaction
			prop.load(fis);
		4. to get a value from properties file
			String userName = prop.getProperty("login.username.id");
			System.out.println(userName);
			System.out.println(prop.getProperty("login.username.id"));
	
	Important Note:-
	==============
	Steps to Make Properties File compatible for Parallel Execution
	===============================================================
	1. Remove the static keyword from the driver						==> public static Properties prop;
	2. Create Constructor in each page with Properties File as argument ==> public Properties prop;
	3. Pass the driver in all the constructor calls						==> return new HomePage(driver, prop);
	   Testcase pass the Driver and Property file 	==> LoginLogout		==> new LoginPage(driver, prop)
	   
	ClassRoom - Cross Browser Testing:-
	=================================

	Implement crossbrowser testing in POM to execute the scripts in chrome & firefox browsers
	
 *******************************************************************************************************************/
package base;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.HomePage;
import pages.LoginPage;

public class ProjectSpecificMethods 
{
	public RemoteWebDriver driver;
	//public static Properties prop; ==> Remove static keyword
	public Properties prop;
	@Parameters({"browser","language"})
	@BeforeMethod
	public void startApplication(String browser,String lang) throws IOException 
	{
		/****************************Properties File Code*******************************/
		FileInputStream fis=new FileInputStream("./src/main/resources/"+lang+".properties");
		prop=new Properties();
		prop.load(fis);
		/****************************Browser and Application Instantiation Code*******************************/
		if(browser.equalsIgnoreCase("Chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		else if (browser.equalsIgnoreCase("Firefox")) 
		{
			WebDriverManager.firefoxdriver().setup();
			driver= new FirefoxDriver();
		}
		else if (browser.equalsIgnoreCase("InternetExplorer")) 
		{
			WebDriverManager.iedriver().setup();
			driver= new InternetExplorerDriver();
		}
		else if (browser.equalsIgnoreCase("Edge")) 
		{
			WebDriverManager.edgedriver().setup();
			driver= new EdgeDriver();
		}
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	@AfterMethod
	public void closeBrowser() 
	{
		driver.close();

	}
	
}
