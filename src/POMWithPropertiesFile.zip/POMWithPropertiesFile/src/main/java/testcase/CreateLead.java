package testcase;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods
{
	@Test
	private void createLead() 
	{
		new LoginPage(driver, prop)
		.enterUserName("demosalesmanager")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickCrmsfa()
		.clickLeadsButton()
		.clickCreateLead()
		.enterCompanyName()
		.enterFirstName()
		.enterLastName()
		.enterPhoneNumber()
		.enterEmail()
		.clickSubmitButton()
		.getTitle();

	}
}
