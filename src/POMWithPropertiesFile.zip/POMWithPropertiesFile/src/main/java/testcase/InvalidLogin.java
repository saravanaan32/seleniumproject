package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class InvalidLogin extends ProjectSpecificMethods
{
	@Test
	public void invalidLogin() 
	{
		//LoginPage lp=new LoginPage(); //instead of creating the object we can directly declare
		new LoginPage(driver,prop)
		.enterUserName("demo123")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickLogout();
	}

}
