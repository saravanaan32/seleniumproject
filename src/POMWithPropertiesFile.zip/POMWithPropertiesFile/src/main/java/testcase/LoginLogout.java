/**************************************************************************************************************************************
	Classroom:
	=========
		1. Create a new project for POM with properties file
		2. Create English.properties and have the locators for login and home page
		3. Integrate the English.properties files into the POM
	Important Note:-
	==============
	Steps to Make Properties File compatible for Parallel Execution
	==========================================
	1. Remove the static keyword from the driver						==> public static Properties prop;
	2. Create Constructor in each page with Properties File as argument ==> public Properties prop;
	3. Pass the driver in all the constructor calls						==> return new HomePage(driver, prop);
	   Testcase pass the Driver and Property file 	==> LoginLogout		==> new LoginPage(driver, prop)
	   
	Constructor Call:-
	================
		public LoginPage(ChromeDriver driver, Properties prop)
		{
			this.driver=driver;
		}
 ***************************************************************************************************************************************/
package testcase;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginLogout extends ProjectSpecificMethods
{
	@Test
	public void loginLogout() 
	{
		//LoginPage lp=new LoginPage(); //instead of creating the object we can directly declare
		new LoginPage(driver, prop)
		.enterUserName("demosalesmanager")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickLogout();
	}
}
