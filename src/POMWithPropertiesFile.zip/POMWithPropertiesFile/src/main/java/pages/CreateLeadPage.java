package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods 
{
	public CreateLeadPage(RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	public CreateLeadPage enterCompanyName() 
	{
		driver.findElementById("createLeadForm_companyName").sendKeys("Sai Enterprises");
		return this;
	}
	public CreateLeadPage enterFirstName() 
	{
		driver.findElementById("createLeadForm_firstName").sendKeys("Saravanan");
		return this;
	}
	public CreateLeadPage enterLastName() 
	{
		driver.findElementById("createLeadForm_lastName").sendKeys("Jeganathan");
		return this;

	}
	public CreateLeadPage enterEmail() 
	{
		driver.findElementByXPath("//input[@id='createLeadForm_primaryEmail']").sendKeys("sai@gmail.com");
		return this;
	}
	public CreateLeadPage enterPhoneNumber() 
	{
		driver.findElementByXPath("//input[@id='createLeadForm_primaryPhoneNumber']").sendKeys("99");
		return this;
	}
	public ViewLeadPage clickSubmitButton() 
	{
		driver.findElementByName("submitButton").click();
		return new ViewLeadPage(driver);
	}
}
