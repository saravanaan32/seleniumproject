package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods 
{
	public ViewLeadPage(RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	public void getTitle() 
	{
		String viewLeads = driver.getTitle();
		System.out.println("The Title Page verification of the Resulting Page:- " + (viewLeads.contains("View Lead")));

	}
}
