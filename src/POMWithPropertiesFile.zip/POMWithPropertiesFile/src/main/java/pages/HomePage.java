package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods 
{
	public HomePage(RemoteWebDriver driver, Properties prop)
	{
		this.driver=driver;
		this.prop=prop;
	}
	public MyHomePage clickCrmsfa() 
	{
		driver.findElementByLinkText("CRM/SFA").click();
		return new MyHomePage(driver,prop);

	}
	public LoginPage clickLogout() 
	{
		driver.findElementByClassName("decorativeSubmit").click();
		//driver.close();
		return new LoginPage(driver,prop);

	}
}
