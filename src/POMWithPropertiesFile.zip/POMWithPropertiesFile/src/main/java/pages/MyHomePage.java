package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods 
{
	public MyHomePage(RemoteWebDriver driver, Properties prop)
	{
		this.driver=driver;
		this.prop=prop;
	}
	public MyLeadsPage clickLeadsButton() 
	{
		driver.findElementByLinkText("Leads").click();
		return new MyLeadsPage(driver);

	}
}
